from django.apps import AppConfig


class DjangoArtisanConfig(AppConfig):
    name = 'django_artisan'
