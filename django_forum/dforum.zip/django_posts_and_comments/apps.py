from django.apps import AppConfig


class DjangoPostsAndCommentsConfig(AppConfig):
    name = 'django_posts_and_comments'
