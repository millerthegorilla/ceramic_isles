from django.apps import AppConfig


class DjangoProfileConfig(AppConfig):
    name = 'django_profile'
