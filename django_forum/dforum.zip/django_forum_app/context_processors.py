from django.conf import settings

def siteName(request):
    return { 'siteName': 'Ceramic Isles' }
