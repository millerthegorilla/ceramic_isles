from django.apps import AppConfig


class DjangoForumAppConfig(AppConfig):
    name = 'django_forum_app'
