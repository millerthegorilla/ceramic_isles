from django.apps import AppConfig


class DjangoUsersAppConfig(AppConfig):
    name = 'django_users_app'
